package com.example.gslclab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class loginActivity extends AppCompatActivity {

    EditText emailTxt, passwordTxt;
    Button loginBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activitylogin);
        init();
    }

    private void init() {

        emailTxt = findViewById(R.id.emailTxt);
        passwordTxt = findViewById(R.id.passwordTxt);
        loginBtn = findViewById(R.id.loginBtn);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String EmailTXT = emailTxt.getText().toString();
                String PasswordTXT = passwordTxt.getText().toString();

                if (EmailTXT.isEmpty()){
                    Toast.makeText(loginActivity.this, "Email must be field", Toast.LENGTH_SHORT).show();
                }else if(!EmailTXT.contains("@")){
                    Toast.makeText(loginActivity.this, "Email must containt '@'", Toast.LENGTH_SHORT).show();
                }else if(!EmailTXT.endsWith(".com") && !EmailTXT.endsWith(".co.id")){
                    Toast.makeText(loginActivity.this, "Email must end with '.com' or '.co.id'", Toast.LENGTH_SHORT).show();
                }else if(EmailTXT.contains("@.") || EmailTXT.contains(".@")){
                    Toast.makeText(loginActivity.this, "Email can't contains '@.' or '.@'", Toast.LENGTH_SHORT).show();
                }else if (PasswordTXT.isEmpty()){
                    Toast.makeText(loginActivity.this, "Password must be field", Toast.LENGTH_SHORT).show();
                }else if (!upperCase(PasswordTXT)){
                    Toast.makeText(loginActivity.this, "Password must containt uppercase", Toast.LENGTH_SHORT).show();
                }else if (!lowerCase(PasswordTXT)) {
                    Toast.makeText(loginActivity.this, "Password must containt lowercase", Toast.LENGTH_SHORT).show();
                }else if (!numeric(PasswordTXT)) {
                    Toast.makeText(loginActivity.this, "Password must containt numeric", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(loginActivity.this, "Login Successed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean upperCase(String PasswordTXT){
        boolean upperCase = true;
        int i;
        for (i = 0; i < PasswordTXT.length(); i++){
            char character = PasswordTXT.charAt(i);
            if (Character.isUpperCase(character)){
                upperCase = false;
            }
        }
        return  upperCase;
    }

    private boolean lowerCase(String passwordTXT){
        boolean lowerCase = true;
        int i;
        for (i = 0; i < passwordTXT.length(); i++){
            char character = passwordTXT.charAt(i);
            if (Character.isUpperCase(character)){
                lowerCase = false;
            }
        }
        return  lowerCase;
    }

    private boolean numeric(String passwordTXT){
        boolean numeric = true;
        int i;
        for (i = 0; i < passwordTXT.length(); i++){
            char character = passwordTXT.charAt(i);
            if (Character.isUpperCase(character)){
                numeric = false;
            }
        }
        return  numeric;
    }

}